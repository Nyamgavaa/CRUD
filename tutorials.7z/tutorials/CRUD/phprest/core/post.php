<?php
class Post{
    //db stuff
    private $conn;
    private $table= 'posts';


    //post properties 

    public $id ;
    public $category_id ;
    public $category_name ;
    public $title ;
    public $body ;
    public $author ;
    public $created_at ;
    public $data = [] ;

 
    // contructor with db connection
    public function __construct($db) { 
        $this->conn = $db; 
    }

    //getting posts from our database
    public function read(){

        //create query
        $query = 'SELECT
            c.name as category_name,
            p.id,
            p.category_id,
            p.title,
            p.body,
            p.author,
            p.created_at
            FROM
           ' . $this->table . ' p
           LEFT JOIN
                categories c ON p.category_id = c.id
           ORDER BY 
                p.created_at DESC '; 
        //prepare statement
        $stmt = $this->conn->prepare($query);

        //execute query
        $stmt->execute();

        return $stmt;

        
    }
    public function read_single($param, $type){
        
        if($type == "author"){
            $query = "SELECT c.NAME AS category_name,
                    p.id,
                    p.category_id,
                    p.title,
                    p.body,
                    p.author,
                    p.created_at
             FROM   posts p
                    LEFT JOIN categories c
                           ON p.category_id = c.id
             WHERE  p.author LIKE '%".$param."%'"; 
        }
        else{
            $query = "SELECT
            c.name as category_name,
            p.id,
            p.category_id,
            p.title,
            p.body,
            p.author,
            p.created_at
            FROM
           " . $this->table . " p
           LEFT JOIN
                categories c ON p.category_id = c.id
                WHERE p.id = $param"; 
        }
        $stmt = $this->conn->prepare($query);
        //execute the query
        $stmt -> execute();
        $row = $stmt -> fetchAll(PDO::FETCH_ASSOC);

        if(sizeof($row) > 0){
            $this -> data = $row;
            $this -> title = $row[0]['title'];
            $this -> body = $row[0]['body'];
            $this -> author = $row[0]['author'];
            $this -> category_id = $row[0]['category_id'];
            $this -> category_name = $row[0]['category_name'];
        }
    }
    
}


?>
