<?php
    $db = "(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=172.29.2.71)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME = gb96)))";

    if($connect = OCILogon("forsoft", "gb96forsoft318454", $db))
    {
        echo "Successfully connected to Oracle.\n";
        OCILogoff($connect);
    }
    else
    {
        $err = OCIError();
        echo "Connection failed." . $err[text];
    }
?>
