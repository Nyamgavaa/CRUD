<?php
include_once('./db.inc.php');

$sql = "select * from forsoft.saving_txn";

$stmt = ociparse($connect, $sql);
ociexecute($stmt, OCI_DEFAULT);
$rows = array();
while ($row = oci_fetch_array($stmt, OCI_ASSOC))
{
    $rows[] = $row;
}
return $rows;

?>