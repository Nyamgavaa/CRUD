<?php
$db_user  = 'root';
$db_password  = '';
$db_name  = 'phprest';



$db = new PDO('mysql:host=127.0.0.1;dbname='.$db_name.';charser=utf8',$db_user,$db_password);

//set some db attributes

$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
$db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


define('APP_NAME', 'PHP REST API TUTORIAL');


// class Database {

//     //DB Params
//     private $host = 'localhost';
//     private $db_name = 'phprest';
//     private $user_name = 'root';
//     private $password = '';
//     private $conn;

//     //DB Connect
//     public function connect() {
//         $this->conn = null;
    

//     try {
//         //$this->conn = new PDO('mysql:host='.$this->host.';dbname='.$this->db_name,$this->user_name,$this->password);
//         $this->conn = new PDO('mysql:host='.$this->host.';dbname='.$this->db_name, $this->user_name, $this->password);
//         $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//     } catch(PDOException $e){
//         echo 'Connection Error' . $e->getMessage();
//     }
//         return $this->conn;
//     }
// }
?>


