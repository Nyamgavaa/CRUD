<?php
//headers
echo "Succuss";
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');


//initializing our api
include_once('../../phprest/core/initialize.php');



//instantiate post 

$post = new Post($db);
// $post->id = isset($_REQUEST['id']) ? $_REQUEST['id'] : die();
// $post->read_single($_REQUEST['id']);
//$post->id = isset($_GET['id']) ? $_GET['id'] : die();
//$post->read_single($_GET['id']);
$post->read_single($_GET['param'],$_GET['type']);

$post_arr = array(
    'data' => $post->data,
    'id' => $post->id,
    'title' => $post->title,
    'body' => $post->body,
    'author' => $post->author,
    'category_id' => $post->category_id,
    'category_name' => $post->category_name,
);

//make a json
print_r(json_encode($post_arr));

